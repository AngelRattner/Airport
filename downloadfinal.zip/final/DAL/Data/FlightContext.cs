﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using Entity.Models;
namespace DAL.Data
{
    public class FlightContext : DbContext
    {

		public FlightContext(DbContextOptions<FlightContext> options) : base(options)
        {
        }
        public DbSet<Plane> Planes { get; set; }
		public DbSet<PlanesOnLegs> PlanesOnLegs { get; set; }
		public DbSet<ArrivalPlane> PlanesInArrivalQueue { get; set; }
		public DbSet<DepartPlane> PlanesInDepartQueue { get; set; }
		public DbSet<FlightLeg> Legs { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<FlightLeg>().HasData(
            new { Id = 1, IsLegAvelable = true,Isdisable=false, Type = (LegType)1 },
            new { Id = 2, IsLegAvelable = true,Isdisable=false, Type = (LegType)2 },
            new { Id = 3, IsLegAvelable = true,Isdisable=false, Type = (LegType)3 },
            new { Id = 4, IsLegAvelable = true,Isdisable=false, Type = (LegType)4 },
            new { Id = 5, IsLegAvelable = true,Isdisable=false, Type = (LegType)5 },
            new { Id = 6, IsLegAvelable = true,Isdisable=false, Type = (LegType)6 },
            new { Id = 7, IsLegAvelable = true,Isdisable=false, Type = (LegType)7 },
            new { Id = 8, IsLegAvelable = true,Isdisable=false, Type = (LegType)8 },
            new { Id = 9, IsLegAvelable = true,Isdisable=false, Type = (LegType)9 });

        }
    }
}
