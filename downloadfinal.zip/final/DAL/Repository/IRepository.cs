﻿using Entity.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DAL.Repository
{
    public interface IRepository
    {
        void NewFlight(Plane plane);
        void NewPlaneOnLeg(PlanesOnLegs plane);
        void newPlaneArrival(ArrivalPlane plane);
        void newPlaneDepart(DepartPlane plane);

        void RemoveArrivaPlane(ArrivalPlane plane);
        void RemovePlaneDepart(DepartPlane plane);
        void RemovePlaneOnLeg(PlanesOnLegs plane);

        PlanesOnLegs GetPlanesByLeg(int legnumber);

        IEnumerable<PlanesOnLegs> GetPlanesInTerminal();
        IEnumerable<ArrivalPlane> GetPlanesArrival();
        IEnumerable<DepartPlane> GetPlanesDepart();

        ArrivalPlane getArrivalfirstPlane();
        DepartPlane getDepartfirstPlane();
        FlightLeg GetLeg(int legNumber);

        void setLeg(int legNumber);
        void disableLeg(int legNumber);

        void UpdatePlnae(PlanesOnLegs plane,FlightLeg flightLeg);
    }
}
