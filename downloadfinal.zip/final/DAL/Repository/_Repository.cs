﻿using DAL.Data;
using Entity.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DAL.Repository
{
    public class _Repository : IRepository
    {
        private FlightContext flightContext;
        public _Repository(FlightContext flightContext)
        {
            this.flightContext = flightContext;
        }
        #region new
        public void NewFlight(Plane plane)
        {
            flightContext.Add(plane);
            flightContext.SaveChanges();
        }
        public void NewPlaneOnLeg(PlanesOnLegs plane)
        {
            flightContext.Add(plane);
            flightContext.SaveChanges();
        }
        public void newPlaneArrival(ArrivalPlane plane)
        {
            flightContext.Add(plane);
            flightContext.SaveChanges();
        }
        public void newPlaneDepart(DepartPlane plane)
        {
            flightContext.Add(plane);
            flightContext.SaveChanges();
        }
        #endregion 
        #region set
        public FlightLeg GetLeg(int legNumber)
        {
            var a = flightContext.Legs.Where(x => (int)x.Type == legNumber).FirstOrDefault();
            return a;
        }
        public void disableLeg(int legNumber)
        {

            var a = flightContext.Legs.FirstOrDefault(x => (int)x.Type == legNumber);
            a.Isdisable = !a.Isdisable;
            flightContext.Update(a);
            flightContext.SaveChanges();

        }
        public void setLeg(int legNumber)
        {
            var a = flightContext.Legs.FirstOrDefault(x => (int)x.Type == legNumber);
            a.IsLegAvelable = !a.IsLegAvelable;
            flightContext.Update(a);
            flightContext.SaveChanges();
        }
        #endregion
        #region remove
        public void RemoveArrivaPlane(ArrivalPlane plane)
        {
            var a = flightContext.PlanesInArrivalQueue.FirstOrDefault(x => x.Id == plane.Id);
            flightContext.Remove(a);
            flightContext.SaveChanges();
        }

        public void RemovePlaneDepart(DepartPlane plane)
        {
            var a = flightContext.PlanesInDepartQueue.FirstOrDefault(x => x.Id == plane.Id);
            flightContext.Remove(a);
            flightContext.SaveChanges();
        }

        public void RemovePlaneOnLeg(PlanesOnLegs plane)
        {
            var a = flightContext.PlanesOnLegs.FirstOrDefault(x => x.Id == plane.Id);
            flightContext.Remove(a);
            flightContext.SaveChanges();
        }
        #endregion
        public void UpdatePlnae(PlanesOnLegs plane, FlightLeg flightLeg)
        {
            var a = flightContext.PlanesOnLegs.FirstOrDefault(x => x.Id == plane.Id);
            a.leg = flightLeg;
            flightContext.Update(a);
            flightContext.SaveChanges();
        }
        #region get
        public PlanesOnLegs GetPlanesByLeg(int legnumber)
        {
            var a = flightContext.PlanesOnLegs.FirstOrDefault(x => (int)x.leg.Type == legnumber);
            return a;
        }

        public IEnumerable<PlanesOnLegs> GetPlanesInTerminal()
        {
            return flightContext.PlanesOnLegs;
        }

        public IEnumerable<ArrivalPlane> GetPlanesArrival()
        {
            return flightContext.PlanesInArrivalQueue;
        }

        public IEnumerable<DepartPlane> GetPlanesDepart()
        {
            return flightContext.PlanesInDepartQueue;
        }

        public ArrivalPlane getArrivalfirstPlane()
        {
            return flightContext.PlanesInArrivalQueue.First();
        }

        public DepartPlane getDepartfirstPlane()
        {
            return flightContext.PlanesInDepartQueue.First();
        }
        #endregion
    }
}
