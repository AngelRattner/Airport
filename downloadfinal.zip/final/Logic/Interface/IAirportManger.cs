﻿using Entity.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace Logic.Interface
{
   public interface IAirportManger
    {
        IEnumerable<PlanesOnLegs> GetPlanes();
        FlightLeg[] GetLegs();
        //void Start();
        void NewFlight(Plane plane);
        void Manger();
    }
}
