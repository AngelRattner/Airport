﻿using DAL.Data;
using DAL.Repository;
using Entity.Models;
using Logic.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Timers;

namespace Logic.AirportManager
{
    public class LegManager : IAirportManger
    {
        //Timer timer = new Timer(5000);
        private readonly IRepository repository;
        public FlightLeg[] Legs { get; set; }
        public bool[] DisableList { get; set; }
        public IEnumerable<PlanesOnLegs> AirplaneOnLeg { get; set; }
        public IEnumerable<ArrivalPlane> ArrivalQueue { get; set; }
        public IEnumerable<DepartPlane> DepartQueue {get; set; }
        public LegManager(IRepository repository)
        {
            Legs = new FlightLeg[10];
            DisableList = new bool[10];
            this.repository = repository;
            for (int i = 1; i < Legs.Length; i++)
            {
                Legs[i] = repository.GetLeg(i);
                DisableList[i] = Legs[i].Isdisable;
            }
            AirplaneOnLeg = repository.GetPlanesInTerminal();
            ArrivalQueue = repository.GetPlanesArrival();
            DepartQueue = repository.GetPlanesDepart();
        }
        private void AdvenceLeg(int currentLeg, int nextLeg,PlanesOnLegs planes)
        {
            repository.UpdatePlnae(planes, repository.GetLeg(nextLeg)); //move plane to next leg and save to data base
            repository.setLeg(currentLeg); //set leg to true in data
            repository.setLeg(nextLeg); //set leg to false in data
            AirplaneOnLeg = repository.GetPlanesInTerminal();//update the list
            Legs[currentLeg].IsLegAvelable = true;
            Legs[nextLeg].IsLegAvelable = false;
        }
     
        private void Manageleg9()
        {//if plane in 4 and it taking off move it to 9
            if (!Legs[4].IsLegAvelable)
            {
                if (FindPlaneByLegNumber(4).takeoff_location == "Isreal")
                {
                    AdvenceLeg(4, 9, FindPlaneByLegNumber(4));
                    Legs[4].IsLegAvelable = true;
                }
            }
        }
        private void MangeDepart()
        {//if plane in 9 remove it
            if (!Legs[9].IsLegAvelable)
            {
                RemovePlane(9);
                AirplaneOnLeg = repository.GetPlanesInTerminal();//update the list
                Legs[9].IsLegAvelable = true;
            }
        }
        private void ManageArrival()
        {//if plane in 6 and its landing remove it
            if (!Legs[6].IsLegAvelable && FindPlaneByLegNumber(6).Landing_location == "Isreal")
            {
                RemovePlane(6);
                AirplaneOnLeg = repository.GetPlanesInTerminal();//update the list
                Legs[6].IsLegAvelable = true;
            }//if plane in 7 and its landing remove it
            if (!Legs[7].IsLegAvelable && FindPlaneByLegNumber(7).Landing_location == "Isreal")
            {
                RemovePlane(7);
                AirplaneOnLeg = repository.GetPlanesInTerminal();//update the list
                Legs[7].IsLegAvelable = true;
            }
        }


        private void Manageleg4()
        {
            if (Legs[4].IsLegAvelable)
            {
                if (!Legs[3].IsLegAvelable && (Legs[8].IsLegAvelable || FindPlaneByLegNumber(3).date < FindPlaneByLegNumber(8).date))
                {
                    AdvenceLeg(3, 4, FindPlaneByLegNumber(3));
                }
                else if (!Legs[8].IsLegAvelable)
                {
                    AdvenceLeg(8, 4, FindPlaneByLegNumber(8));
                }
            }
        }

        private void Manageleg8()
        {       //ck if 8 avelable else leave
            if (Legs[8].IsLegAvelable)
            {       //if 7 empty and 6 isnt
                if (!Legs[6].IsLegAvelable && Legs[7].IsLegAvelable)
                {//take 6 to 8
                    AdvenceLeg(6, 8,FindPlaneByLegNumber(6));
                }//if 6 is empty and 7 isnt
                else if (!Legs[7].IsLegAvelable && Legs[6].IsLegAvelable)
                {//move 7 to 8
                    AdvenceLeg(7, 8, FindPlaneByLegNumber(7));
                }//if both have plane init
                else if (!Legs[7].IsLegAvelable && !Legs[6].IsLegAvelable)
                {   //and 6 was before 7 move 6
                    //if (FindPlaneByLegNumber(6).date < FindPlaneByLegNumber(7).date)
                    //{
                        AdvenceLeg(6, 8, FindPlaneByLegNumber(6));
                    //}//else move 7
                    //else
                    //{
                    //    AdvenceLeg(7, 8, FindPlaneByLegNumber(7));
                    //}
                }
            }
        }

        private void Manageleg6()
        {
            if (Legs[6].IsLegAvelable)
            {
                if (Legs[8].IsLegAvelable || Legs[7].IsLegAvelable || FindPlaneByLegNumber(7).Landing_location == "Isreal")
                {
                    if (DepartQueue.Count() != 0)
                    {
                        if (!Legs[5].IsLegAvelable && FindPlaneByLegNumber(5).date < repository.getDepartfirstPlane().date)
                        {
                            AdvenceLeg(5, 6, FindPlaneByLegNumber(5));
                            return;
                        }
                        else
                        {
                            repository.setLeg(6);//set leg to flase
                            DepartPlane departPlane = repository.getDepartfirstPlane();
                            PlanesOnLegs planesOnLegs = new PlanesOnLegs()
                            {
                                date = departPlane.date,
                                Landing_location = departPlane.Landing_location,
                                takeoff_location = departPlane.takeoff_location,
                                Id = departPlane.Id,
                                leg = repository.GetLeg(6)
                            };
                            repository.NewPlaneOnLeg(planesOnLegs);//add the plane to list of terminal
                            repository.RemovePlaneDepart(departPlane);//remove plane from Q list
                            return;
                        }
                    }
                }
                if (!Legs[5].IsLegAvelable) AdvenceLeg(5, 7, FindPlaneByLegNumber(5));
            }
        }
        private void Manageleg7()
        {       //if 7 is avelable and 8 avelable  or 6 avelable or 6 is landing, then we can put plane in 7
            if (Legs[7].IsLegAvelable)
            {
                if (Legs[8].IsLegAvelable || Legs[6].IsLegAvelable || FindPlaneByLegNumber(6).Landing_location == "Isreal")
                {

                    {       //if plane wating to fly
                        if (DepartQueue.Count() != 0)
                        {         //if 5 waiting to land and 5was before the queue move 5 to 7
                            if (!Legs[5].IsLegAvelable && FindPlaneByLegNumber(5).date < repository.getDepartfirstPlane().date)
                            {
                                AdvenceLeg(5, 7, FindPlaneByLegNumber(5));
                                return;
                            }
                            else //if 5 is empty or the queue was first dequeue first
                            {
                                repository.setLeg(7);//set leg to flase
                                DepartPlane departPlane = repository.getDepartfirstPlane();//get the first plane in queue
                                PlanesOnLegs planesOnLegs = new PlanesOnLegs()
                                {
                                    date = departPlane.date,
                                    Landing_location = departPlane.Landing_location,
                                    takeoff_location = departPlane.takeoff_location,
                                    Id = departPlane.Id,
                                    leg = repository.GetLeg(7)
                                };
                                repository.NewPlaneOnLeg(planesOnLegs);
                                repository.RemovePlaneDepart(departPlane);
                                return;
                            }
                        }
                    }
                }
                if (!Legs[5].IsLegAvelable) AdvenceLeg(5, 7, FindPlaneByLegNumber(5));
            }
        }

        private void Manageleg5()
        {
            if (Legs[5].IsLegAvelable)//ck that 5 is avelable
            {
                if (!Legs[4].IsLegAvelable && FindPlaneByLegNumber(4).Landing_location == "Isreal")
                {//if 4 have plane and that plane is lnding go to leg 5
                    AdvenceLeg(4, 5, FindPlaneByLegNumber(4));
                }
            }
        }


        private void Manageleg1()
        {//of 1 is epty and plane wait to land
            if (Legs[1].IsLegAvelable &&ArrivalQueue.Count()!=0)
            {
                repository.setLeg(1);//set 1 from true to flase
                ArrivalPlane arrivalPlane = repository.getArrivalfirstPlane(); //dequeue and save the plane
                PlanesOnLegs planesOnLegs = new PlanesOnLegs() //transfer the data to the new type
                {
                    date = arrivalPlane.date,
                    Id = arrivalPlane.Id,
                    Landing_location = arrivalPlane.Landing_location,
                    takeoff_location = arrivalPlane.takeoff_location,
                    leg = repository.GetLeg(1)
                };
                repository.NewPlaneOnLeg(planesOnLegs);//add the plane to dat base
                repository.RemoveArrivaPlane(arrivalPlane);//remove plane from data base
            }
        }
        private void Manageleg2()
        {
            if (Legs[2].IsLegAvelable &&!Legs[1].IsLegAvelable)//if 2 is clean and 1 isnt
            {
                AdvenceLeg(1, 2, FindPlaneByLegNumber(1)); //move from 1 to 2
            }
        }
        private void Manageleg3()
        {
            if (Legs[3].IsLegAvelable &&!Legs[2].IsLegAvelable)//if 3 is clean and 2 isnt
            {
                AdvenceLeg(2, 3, FindPlaneByLegNumber(2));//move plane from 2 to 3
            }
        }

        private PlanesOnLegs FindPlaneByLegNumber(int Legnumber)
        {
            foreach (var item in AirplaneOnLeg)
            {
                if (item.leg.Id == Legnumber) return item;
            }
            return null;
        }
        public void NewFlight(Plane plane)
        {
            if (plane.Landing_location == "Isreal")
            {
                
                ArrivalPlane arrivalPlane = new ArrivalPlane()
                {
                    Id = plane.Id,
                    takeoff_location = plane.takeoff_location,
                    Landing_location = plane.Landing_location,
                    date = plane.date
                };
                repository.newPlaneArrival(arrivalPlane);
                Manger();
            }
            else
            {  
                DepartPlane departPlane = new DepartPlane()
                {
                    Id = plane.Id,
                    takeoff_location = plane.takeoff_location,
                    Landing_location = plane.Landing_location,
                    date = plane.date
                }; 
                repository.newPlaneDepart(departPlane);
                Manger();
            }
        }
        public void RemovePlane(int legNum)
        {
            PlanesOnLegs planesOnLegs = repository.GetPlanesByLeg(legNum);//find the plane to remove
            repository.RemovePlaneOnLeg(planesOnLegs);//tell data to remove
            Legs[legNum].IsLegAvelable = true; //set leg in mnager to true
            repository.setLeg(legNum); //set leg in data base to true
        }

        public void Manger()
        {
            MangeDepart();//rome plane in 9
            ManageArrival();//remove plane in 6 &7
            Manageleg9();
            if (!DisableList[4]) Manageleg4();
            if (!DisableList[8]) Manageleg8();
            if (!DisableList[6]) Manageleg6();
            if (!DisableList[7]) Manageleg7();
            if (!DisableList[5]) Manageleg5();
            if (!DisableList[3]) Manageleg3();
            if (!DisableList[2]) Manageleg2();
            if (!DisableList[1]) Manageleg1();
        }

        private DepartPlane DepartDequeue(IEnumerable<DepartPlane> queue)
        {
            foreach (var item in queue)
            {
                return item;
            }
            return null;
        }
        private ArrivalPlane ArrivalDequeue(IEnumerable<ArrivalPlane> queue)
        {
            foreach (var item in queue)
            {
                return item;
            }
            return null;
        }
        public IEnumerable<PlanesOnLegs> GetPlanes()
        {
            return AirplaneOnLeg;
        }

        public FlightLeg[] GetLegs()
        {
            return Legs;
        }
    }
}
