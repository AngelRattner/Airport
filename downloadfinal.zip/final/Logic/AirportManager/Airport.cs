﻿using Logic.Interface;
using Entity.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Timers;

namespace Logic.AirportManager
{
    public class Airport //: IAirportManger
    {
        //Timer timer = new Timer(5000);
        //public FlightLeg[] Legs = new FlightLeg[10];
        //public List<Plane> AirplaneOnLeg = new List<Plane>();
        //public Queue<Plane> ArrivalQueue { get; set; }
        //public Queue<Plane> DepartQueue { get; set; }
        //public Airport()
        //{
        //    for (int i = 1; i < 10; i++)
        //    {
        //        Legs[i] = new FlightLeg { IsLegAvelable = true, Type = (LegType)i };
        //    }
        //    ArrivalQueue = new Queue<Plane>();
        //    DepartQueue = new Queue<Plane>();
        //}

        //private void Manger(object s, EventArgs e)
        //{
        //    bool stop;
        //    ManageDepart();
        //    ManageArrival();

        //    stop = Manageleg1();
        //    if (stop) return;
        //    stop = Manageleg7();
        //    if (stop) return;
        //    stop = Manageleg6();
        //    if (stop) return;
        //    stop = Manageleg5();
        //    if (stop) return;
        //    stop = Manageleg4();
        //    if (stop) return;
        //    stop = Manageleg3();
        //    if (stop) return;
        //    stop = Manageleg2();
        //    if (stop) return;
        //    stop = Manageleg8();
        //    if (stop) return;
        //}

        //public void NewFlight(Plane plane)
        //{
        //    if (plane.Landing_location == "Isreal")
        //    {
        //        ArrivalQueue.Enqueue(plane);
        //    }
        //    else
        //    {
        //        DepartQueue.Enqueue(plane);
        //    }
        //}

        //private bool Manageleg1()
        //{
        //    if (Legs[1].IsLegAvelable && ArrivalQueue.Count != 0)
        //    {
        //        Legs[1].IsLegAvelable = false;
        //        ArrivalQueue.Peek().leg = Legs[1];
        //        AirplaneOnLeg.Add(ArrivalQueue.Dequeue());
        //        return true;
        //    }
        //    return false;
        //}
        //private bool Manageleg2()
        //{
        //    if (Legs[2].IsLegAvelable)
        //    {
        //        if (!Legs[1].IsLegAvelable)
        //        {
        //            AdvenceLeg(1, 2);
        //            Legs[1].IsLegAvelable = true;
        //            return true;
        //        }
        //    }
        //    return false;
        //}
        //private bool Manageleg3()
        //{
        //    if (Legs[3].IsLegAvelable)
        //    {
        //        if (!Legs[2].IsLegAvelable)
        //        {
        //            AdvenceLeg(2, 3);
        //            Legs[2].IsLegAvelable = true;
        //            return true;
        //        }
        //    }
        //    return false;
        //}


        //private bool Manageleg4()
        //{
        //    if (Legs[4].IsLegAvelable && AirplaneOnLeg.Count != 0)
        //    {
        //        if (!Legs[3].IsLegAvelable && (Legs[8].IsLegAvelable || FindPlaneByLegNumber(3).date < FindPlaneByLegNumber(8).date))
        //        {
        //            AdvenceLeg(3, 4);
        //            Legs[3].IsLegAvelable = true;
        //            return true;
        //        }
        //        else if (!Legs[8].IsLegAvelable)
        //        {
        //            AdvenceLeg(8, 4);
        //            Legs[8].IsLegAvelable = true;
        //            return true;
        //        }
        //    }
        //    return false;
        //}

        //private bool Manageleg5()
        //{
        //    if (Legs[5].IsLegAvelable)
        //    {
        //        if (!Legs[4].IsLegAvelable && FindPlaneByLegNumber(4).Landing_location == "Isreal")
        //        {
        //            AdvenceLeg(4, 5);
        //            Legs[4].IsLegAvelable = true;
        //            return true;
        //        }
        //    }
        //    return false;
        //}


        //private bool Manageleg6()
        //{
        //    if (Legs[6].IsLegAvelable && (Legs[8].IsLegAvelable || Legs[7].IsLegAvelable || FindPlaneByLegNumber(7).takeoff_location != "Isreal"))
        //    {
        //        if (DepartQueue.Count != 0)
        //        {
        //            if (!Legs[5].IsLegAvelable && FindPlaneByLegNumber(5).date < DepartQueue.Peek().date) AdvenceLeg(5, 6);
        //            else
        //            {
        //                Legs[6].IsLegAvelable = false;
        //                DepartQueue.Peek().leg = Legs[6];
        //                AirplaneOnLeg.Add(DepartQueue.Dequeue());
        //                return true;
        //            }
        //        }
        //    }
        //    return false;
        //}
        //private bool Manageleg7()
        //{
        //    if (Legs[7].IsLegAvelable && (Legs[8].IsLegAvelable || Legs[6].IsLegAvelable || FindPlaneByLegNumber(6).takeoff_location != "Isreal"))
        //    {
        //        if (DepartQueue.Count != 0)
        //        {
        //            if (!Legs[5].IsLegAvelable && FindPlaneByLegNumber(5).date < DepartQueue.Peek().date) AdvenceLeg(5, 7);
        //            else
        //            {
        //                Legs[7].IsLegAvelable = false;
        //                DepartQueue.Peek().leg = Legs[7];
        //                AirplaneOnLeg.Add(DepartQueue.Dequeue());
        //                return true;
        //            }
        //        }
        //    }
        //    return false;
        //}

        //private bool Manageleg8()
        //{
        //    if (Legs[8].IsLegAvelable)
        //    {
        //        if (!Legs[6].IsLegAvelable && Legs[7].IsLegAvelable)
        //        {
        //            AdvenceLeg(6, 8);
        //            Legs[6].IsLegAvelable = true;
        //            return true;
        //        }
        //        else if (!Legs[7].IsLegAvelable && Legs[6].IsLegAvelable)
        //        {
        //            AdvenceLeg(7, 8);
        //            Legs[7].IsLegAvelable = true;
        //            return true;
        //        }
        //        else if (!Legs[7].IsLegAvelable && !Legs[6].IsLegAvelable)
        //        {
        //            if (FindPlaneByLegNumber(6).date < FindPlaneByLegNumber(7).date)
        //            {
        //                AdvenceLeg(6, 8);
        //                Legs[6].IsLegAvelable = true;
        //                return true;
        //            }
        //            else
        //            {
        //                AdvenceLeg(7, 8);
        //                Legs[7].IsLegAvelable = true;
        //                return true;
        //            }
        //        }
        //    }
        //    return false;
        //}

        //private void ManageDepart()
        //{
        //    if (!Legs[4].IsLegAvelable && FindPlaneByLegNumber(4).takeoff_location == "Isreal")
        //    {
        //        AdvenceLeg(4, 9);
        //        RemovePlane(9);
        //        Legs[4].IsLegAvelable = true;
        //        Legs[9].IsLegAvelable = true;
        //    }
        //}
        //private void ManageArrival()
        //{
        //    if (AirplaneOnLeg.Count != 0)
        //    {
        //        if (!Legs[6].IsLegAvelable && FindPlaneByLegNumber(6).Landing_location == "Isreal")
        //        {
        //            RemovePlane(6);
        //            Legs[6].IsLegAvelable = true;
        //        }
        //       else if (!Legs[7].IsLegAvelable && FindPlaneByLegNumber(7).Landing_location == "Isreal")
        //        {
        //            RemovePlane(7);
        //            Legs[7].IsLegAvelable = true;
        //        }
        //    }
        //}

        //private void AdvenceLeg(int currentLeg, int nextLeg)
        //{
        //    FlightLeg tmp=new FlightLeg();
        //    for (int i = 1; i < Legs.Length; i++)
        //    {
        //        if ((int)Legs[i].Type == nextLeg) tmp = Legs[i];
        //    }
        //    FindPlaneByLegNumber(currentLeg).leg = tmp;
        //    Legs[currentLeg].IsLegAvelable = true;
        //    Legs[nextLeg].IsLegAvelable = false;
        //}

        //private Plane FindPlaneByLegNumber(int Legnumber)
        //{
        //    for (int i = 0; i < AirplaneOnLeg.Count; i++) //airplane list
        //    {
        //        for (int j = 1; j < 10; j++) // legs list
        //        {
        //            if (AirplaneOnLeg[i].leg.Type == Legs[j].Type) return AirplaneOnLeg[i];
        //        }
        //    }
        //    return null;
        //}
        //private void RemovePlane(int Legnumber)
        //{
        //    for (int i = 0; i < AirplaneOnLeg.Count; i++) //airplane list
        //    {
        //        for (int j = 1; j < 10; j++) // legs list
        //        {
        //            if (AirplaneOnLeg[i].leg.Type == Legs[j].Type) { AirplaneOnLeg.RemoveAt(i); break; }
        //        }
        //    }
        //}
        //public List<Plane> GetPlanes()
        //{
        //    return AirplaneOnLeg;
        //}
        //public void Start()
        //{
        //    timer.Elapsed += Manger;
        //    timer.Start();
        //    timer.AutoReset = true;
        //}

        //public FlightLeg[] GetLegs()
        //{
        //    return Legs;
        //}

        //List<PlanesOnLegs> IAirportManger.GetPlanes()
        //{
        //    throw new NotImplementedException();
        //}
    }
}
