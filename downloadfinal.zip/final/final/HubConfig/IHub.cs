﻿using Entity.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Server.HubConfig
{
    public interface IHub
    {
        public Task askServer(IEnumerable<PlanesOnLegs> planes);
        public Task updateLegList(FlightLeg[] legs);
    }
}
