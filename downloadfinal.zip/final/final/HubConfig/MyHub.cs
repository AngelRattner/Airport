﻿using DAL.Repository;
using Entity.Models;
using Microsoft.AspNetCore.SignalR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Server.HubConfig
{
    public class MyHub : Hub, IHub
    {
        protected IHubContext<MyHub> _context;
        private readonly IRepository repository;
        public MyHub(IHubContext<MyHub> context, IRepository repository)
        {
            this.repository = repository;
            _context = context;
        }

        public async Task askServer(IEnumerable<PlanesOnLegs> planes)
        {
            await _context.Clients.All.SendAsync("askServerResponse", planes);
        }
        public async Task updateLegList(FlightLeg[] legs)
        {
            await _context.Clients.All.SendAsync("LegList", legs);
        }
        public async Task leg(int legID)
        {
            Console.WriteLine(legID + "is disable");
            repository.disableLeg(legID);
        }
    }
}
