using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SimulatorManager.Logic;
using SimulatorManager.Interface;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Server.HubConfig;
using Logic.AirportManager;
using Logic.Interface;
using DAL.Repository;
using DAL.Data;

namespace Server
{
    public class Startup
    {
        private IConfiguration _configuration;

        public Startup(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public void ConfigureServices(IServiceCollection services)
        {
            services.AddTransient<IHub, MyHub>();
            services.AddTransient<IRepository, _Repository>();
            services.AddSingleton<IAirport, Airport_Simulator>();
            services.AddTransient<IAirportManger, LegManager>();
            string connectionString = _configuration.GetConnectionString("DefaultConnection");
            services.AddDbContext<FlightContext>(options => options.UseLazyLoadingProxies().UseSqlServer(connectionString));
            services.AddControllersWithViews();
            services.AddCors(options =>
            {
                options.AddPolicy("AllowAllHeaders", builder =>
                {
                    builder.AllowAnyOrigin().AllowAnyHeader().AllowAnyMethod();
                });
            });
            services.AddSignalR(options =>
            {
                options.EnableDetailedErrors = true;
            });
        }

     
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env, FlightContext Plane)
        {
            Plane.Database.EnsureDeleted();
            Plane.Database.EnsureCreated();

            app.UseRouting();

            app.UseCors("AllowAllHeaders");

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllerRoute("Default", "{controller=Home}/{action=Index}/{id?}");
                endpoints.MapHub<MyHub>("/socket");
            });
        }
    }
}
