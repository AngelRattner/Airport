﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Entity.Models;
using SimulatorManager.Interface;
using SimulatorManager.Logic;
using Microsoft.AspNetCore.Mvc;
using DAL.Repository;
using Server.HubConfig;
using Logic.Interface;

namespace Server.Controllers
{
    public class HomeController : Controller
    {
        private static bool start = false;
        private static bool startManger = false;
        private readonly IAirport airport;
        private readonly IHub hub;
        private readonly IAirportManger manger;
        private readonly IRepository repository;

        public HomeController(IRepository repository, IAirport airport, IHub hub, IAirportManger manger)
        {
            this.repository = repository;
            this.airport = airport;
            this.hub = hub;
            this.manger = manger;
        }
        public IActionResult Index()
        {
            if (!start)
            {
                airport.start();
                start = true;
            }
            if (!startManger)
            {
                //manger.Start();
                start = true;
                hub.updateLegList(manger.GetLegs());//ui legs
            }
            return View();
        }
        [HttpPost]
        public void NewFlight([FromBody]Plane plane)
        {
            repository.NewFlight(plane);//data base
            manger.NewFlight(plane);//manger
            hub.askServer(manger.GetPlanes());//UI planes
            hub.updateLegList(manger.GetLegs());//ui legs
           // manger.Manger();
        }
    }
}
