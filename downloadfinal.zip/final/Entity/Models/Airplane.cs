﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entity.Models
{
    public abstract class Airplane
    {
        public string Id { get; set; }
        public string takeoff_location { get; set; }
        public string Landing_location { get; set; }
        public DateTime date { get; set; }
    }
}
