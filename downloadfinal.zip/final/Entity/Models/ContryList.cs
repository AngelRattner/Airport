﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entity.Models
{
    public enum ContryList
    {
        Germeny,
        Spain,
        Russia,
        China,
        Mexico,
        Australia,
        Japan,
        Greece,
        Netherlands,
        Poland,
        Brazil,
        India
    }

}


