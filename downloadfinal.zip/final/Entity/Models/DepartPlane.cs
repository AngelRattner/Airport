﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entity.Models
{
   public class DepartPlane : Airplane
    {
    }
}
