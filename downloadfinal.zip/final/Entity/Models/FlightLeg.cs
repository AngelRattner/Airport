﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Entity.Models
{
    public class FlightLeg
    {
        [Key]
        public int Id { get; set; }
        public LegType Type { get; set; }
        public bool Isdisable { get; set; }
        public bool IsLegAvelable { get; set; }
    }



    public enum LegType
    {
        Enter = 1,
        PreLanding = 2,
        Landing = 3,
        Runaway = 4,
        Arrivals = 5,
        Terminal = 6,
        Departures = 8,
        Exit = 9
    }

}

