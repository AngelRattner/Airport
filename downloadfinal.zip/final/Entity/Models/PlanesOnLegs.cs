﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entity.Models
{
   public class PlanesOnLegs : Airplane
    {
        public virtual FlightLeg leg { get; set; }
    }
}
