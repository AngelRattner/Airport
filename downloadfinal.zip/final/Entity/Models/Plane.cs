﻿using System;
namespace Entity.Models
{
    public class Plane :Airplane
    {
    }
}

