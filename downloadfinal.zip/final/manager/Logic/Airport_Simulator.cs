﻿using Entity.Models;
using SimulatorManager.Interface;
using Nancy.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Text;
using System.Timers;

namespace SimulatorManager.Logic
{
    public class Airport_Simulator : IAirport
    {
        //Queue<object> planesQueue= new Queue<object>();
        Arrival_Simulator arrival_Simulator = new Arrival_Simulator();
        Departure_Simulator departure_Simulator = new Departure_Simulator();
        Timer timer = new Timer(30000);
        Random random = new Random();
        string _serverBaseUrl= "http://localhost:5000/Home";  
        public void start()
        {
            timer.Elapsed += GenratePlane;
            timer.Start();
            timer.AutoReset = true;
        }
        private void GenratePlane(object s,EventArgs e){
            Plane plane = new Plane();
            if (random.Next(0,2)==0)  plane= arrival_Simulator.GenratePlane();
            else plane= departure_Simulator.GenratePlane();
            SendFlight(plane);
            }


        void SendFlight(Plane plane)
        {
            var httpWebRequest = (HttpWebRequest)WebRequest.Create($"{_serverBaseUrl}/NewFlight");
            httpWebRequest.ContentType = "application/json";
            httpWebRequest.Method = "POST";
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;

            using (var streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
            {
                string json = new JavaScriptSerializer().Serialize(plane);
                streamWriter.Write(json);
                streamWriter.Flush();
                streamWriter.Close();
            }

            var httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();
            using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
            {
                var result = streamReader.ReadToEnd();
            }
        }

    }
}
