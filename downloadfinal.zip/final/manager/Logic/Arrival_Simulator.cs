﻿using Entity.Models;
using SimulatorManager.Interface;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Timers;

namespace SimulatorManager.Logic
{
    class Arrival_Simulator : IArrival_Simulator
    {
        public Plane GenratePlane()
        {
            Random rnd = new Random();
            Guid uuid = Guid.NewGuid();
            var contry = (ContryList)rnd.Next(0, Enum.GetNames(typeof(ContryList)).Length);
            Plane a = new Plane() { Id = uuid.ToString(), takeoff_location = contry.ToString(), Landing_location = "Isreal", date = DateTime.Now};
            return a;
        }
    }
}
