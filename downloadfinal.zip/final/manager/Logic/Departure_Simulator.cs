﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Timers;
using Entity.Models;
using SimulatorManager.Interface;
namespace SimulatorManager.Logic
{
    class Departure_Simulator : IDeparture_Simulator
    {
        public Plane GenratePlane()
        {
            Random rnd = new Random();
            Guid uuid = Guid.NewGuid();
            var contry = (ContryList)rnd.Next(0, Enum.GetNames(typeof(ContryList)).Length);
            Plane a = new Plane() { Id = uuid.ToString(), takeoff_location = "Isreal", Landing_location = contry.ToString(), date = DateTime.Now};
            return a;
        }
    }
}
