﻿using Entity.Models;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace SimulatorManager.Interface
{
    interface IDeparture_Simulator
    {
        Plane GenratePlane();
    }
}
